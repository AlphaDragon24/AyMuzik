#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "=== AyMuzik Termux Kurulumu ==="
pkg update -y
pkg install -y python ffmpeg git nodejs-lts

echo "Python paketleri kuruluyor (flask, yt-dlp)..."
pip install --upgrade pip
pip install flask yt-dlp

echo "Depolama izni isteniyor (Downloads/AyMuzik icin)..."
termux-setup-storage || true

echo ""
echo "Kurulum tamamlandi!"
echo "Baslatmak icin: python server.py"
echo "Ardindan tarayicidan acin: http://127.0.0.1:5050"
