import os
import re
import subprocess
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DL_DIR = Path.home() / "storage" / "downloads" / "AyMuzik"
if not (Path.home() / "storage" / "downloads").exists():
    DL_DIR = BASE_DIR / "downloads"
DL_DIR.mkdir(parents=True, exist_ok=True)


def safe_name(name: str) -> str:
    return re.sub(r'[\\/*?:"<>|]+', "", name).strip()[:80] or "aymuzik_medya"


@app.route("/")
def index():
    return send_from_directory(BASE_DIR, "aymuzik.html")


@app.route("/files/<path:filename>")
def serve_file(filename):
    return send_from_directory(DL_DIR, filename, as_attachment=True)


@app.route("/api/download")
def api_download():
    url = (request.args.get("url") or "").strip()
    mode = (request.args.get("mode") or "mp3").lower()
    if not url:
        return jsonify({"ok": False, "error": "URL eksik"}), 400

    out_tpl = str(DL_DIR / "%(title)s.%(ext)s")
    if mode == "mp4":
        cmd = [
            "yt-dlp",
            "-f", "best[ext=mp4]/best",
            "-o", out_tpl,
            "--print", "after_move:filepath",
            url,
        ]
    else:
        cmd = [
            "yt-dlp",
            "-x",
            "--audio-format", "mp3",
            "--audio-quality", "0",
            "-o", out_tpl,
            "--print", "after_move:filepath",
            url,
        ]

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        lines = [ln.strip() for ln in res.stdout.splitlines() if ln.strip()]
        filepath = Path(lines[-1]) if lines else None
        if filepath and filepath.exists():
            return jsonify({
                "ok": True,
                "filename": filepath.name,
                "file_url": f"/files/{filepath.name}",
            })
        return jsonify({"ok": False, "error": "Dosya olusturulamadi"}), 500
    except subprocess.CalledProcessError as e:
        return jsonify({"ok": False, "error": e.stderr[-300:]}), 500


if __name__ == "__main__":
    print(f"AyMuzik Termux Sunucusu calisiyor -> http://127.0.0.1:5050")
    print(f"Indirme klasoru: {DL_DIR}")
    app.run(host="127.0.0.1", port=5050)
